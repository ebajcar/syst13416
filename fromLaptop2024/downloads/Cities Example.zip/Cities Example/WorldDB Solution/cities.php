<?php
include "connect.php";

class City {

    public $name;
    public $population;
    public $country;

    function __construct($name, $population, $country) {
        $this->name = $name;
        $this->population = $population;
        $this->country = $country;
    }

    function outputRow() {
        return "<tr><td>$this->name</td><td>$this->country</td><td>$this->population</td></tr>";
    }

}

// get the post params
$min = filter_input(INPUT_GET, "min", FILTER_VALIDATE_INT);
$max = filter_input(INPUT_GET, "max", FILTER_VALIDATE_INT);

if ($min !== null && $max !== null) {
    $command = "SELECT Name, CountryCode, Population FROM City WHERE Population>=? AND Population<=? ORDER BY Population";
    $stmt = $dbh->prepare($command);
    $stmt->execute(array($min, $max));
    $cities = array();
    while ($row = $stmt->fetch()) {
        array_push($cities, new City($row["Name"], $row["Population"], $row["CountryCode"]));
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>World City Database Exercise</title>
        <meta charset="ISO8859-1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <h1>Cities Selected</h1>
        <table>
            <tr><th>City Name</th><th>Country</th><th>Population</th></tr>
            <?php
            foreach ($cities as $city) {
                echo $city->outputRow(); 
            }
            ?>
        </table>
    </body>
</html>
