# version 2

### Date: October 2, 2020

### Topic:  8 Scientific health benefits of sleep and sleeping tips

### Recall

what are cortisol, insulin, testosterone?

what is the optimal amount of sleep?

when is the best time to study?

what is melatonin?

why is it important to block out light?

what is optimal nap duration?

### Notes

Benefits 

1. obesity: factor 55% adults, 89% children likelihood of obesity if not enough sleep
2. energy: sleep improves hormonal control, reduces stress, insulin sensitivity
3. immune system ; fights off being sick; less than 7 hours, 3x likelihood of getting cold
4. learning improvement
5. lowers depression (sleep apnea)
6. eat less when you sleep less
7. recognize facial expressions in others
8. athletic performance: reaction times, speed, accuracy

---

Tips

- block all light
- routine, habitual
- use bed only for sleeping
- pillow under legs, posture
- cat naps

<aside>
📌 **SUMMARY: The right amount of sleep helps to strengthen our immune system and hormonal balance; we feel better, perform better physically and mentally, feel healthy and happy. To improve our sleep we create a routine and environment that cues our body that it is time to sleep.**

</aside>